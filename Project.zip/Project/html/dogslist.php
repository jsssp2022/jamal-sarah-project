<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Registered Dogs</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">

    <meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<!--Get your own code at fontawesome.com-->

    <!-- Bootstrap core CSS -->
<link href="/docs/5.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <script src="../js/bootstrap.js"></script>
    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.1/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.1/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.1/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
<link rel="icon" href="/docs/5.1/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#7952b3">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      
      body{
          
          background-color: lightblue;
          
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
  </head>
  <body>
    
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand">Registerd Dogs</a>
       <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
     

        </ul>
        <form class="d-flex">
          <button type="button" class="btn btn-outline-success" style="margin-right: 18%" onclick="window.location.href='https://jssspproject.000webhostapp.com/Project/html/Main.php'">Home</button>

        </form>
        
      </div>
   
        
      </div>
    </div>
  </nav>
</header>


<div style=" margin-top: 5%;margin-right: 18%;margin-left: 18%;">
<?php 

  require_once 'login.php';
  $conn = new mysqli($hn, $un, $pw, $db);
  if ($conn->connect_error) die($conn->connect_error);


  if (isset($_POST['delete']) && isset($_POST['dogid']))
  {
    $dogid   = get_post($conn, 'dogid');
    $query  = "DELETE FROM dogs WHERE dogid='$dogid'";
    $result = $conn->query($query);
  	if (!$result) echo "DELETE failed: $query<br>" .
      $conn->error . "<br><br>";
  }
  
$query  = "SELECT * FROM dogs";
  $result = $conn->query($query);
  if (!$result) die ("Database access failed: " . $conn->error);

  $rows = $result->num_rows;
  
  for ($j = 0 ; $j < $rows ; ++$j)
  {
    $result->data_seek($j);
    $row = $result->fetch_array(MYSQLI_NUM);

    

  
       $row[0];
         $row[1];
        $row[2];
       $row[3];
         $row[4];
       $row[5];
  $row[6];
 $row[7];
 $row[8];
 echo <<<_END
  <form action="dogslist.php" method="post">
  <input type="hidden" name="dogid" value="$row[0]">
 
  <input type="hidden" name="delete" value="yes">
 
    
            <table class="table table-success table-striped">
           
           <tr class="table-danger">
           <td class="table-danger">Dog ID:          $row[0]</td>
           </tr>
           
           <tr>
           <td>Name:            $row[1]</td>
           </tr>
           
           <tr>
           <td>Breed:           $row[2]</td>
           </tr>
           
           <tr>
           <td>Gender:          $row[3]</td>
           </tr>
           
           <tr>
           <td>Age:             $row[4]</td>
           </tr>
           
           <tr>
           <td>Food:            $row[5]</td>
           </tr>
           
           <tr>
           <td>Special Toy:     $row[6]</td>
           </tr>
           
           <tr>
           <td>Coat Length:     $row[7]</td>
           </tr>
           
           <tr>
           <td>Temperament:     $row[8]</td>
           </tr>
           
           <tr>
           <td> <input type="submit" class="btn btn-danger" value="Delete The Dog :("> </td>
           </tr>
           
            </table>
            
            <br>
            <br>
            <br>
        
  </form>
_END;

  }
  

  
  function get_post($conn, $var)
  {
    return $conn->real_escape_string($_POST[$var]);
  }
?>




    <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      
  </body>
</html>