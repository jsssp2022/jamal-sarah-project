<?php
// login.php
    $hn = 'localhost'; //hostname
    $db = 'id18218981_allpets'; //database
    $un = 'id18218981_pets'; //username
   $pw = '3rf9}6!PdXCoc-p]'; //password
?>